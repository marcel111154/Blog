package com.example.blog;

public class Contact {
    int _id;
    String _name;
    String _family;
    String _email;
    String _pass;
    String _pass1;
    public Contact(){   }
    public Contact(int id, String name, String family, String email, String pass, String pass1){
        this._id = id;
        this._name = name;
        this._family = family;
        this._email = email;
        this._pass = pass;
        this._pass1 = pass1;
    }

    public Contact(String name, String family, String email, String pass, String pass1){
        this._name = name;
        this._family = family;
        this._email = email;
        this._pass = pass;
        this._pass1 = pass1;
    }
    public int getID(){
        return this._id;
    }

    public void setID(int id){
        this._id = id;
    }

    public String getName(){
        return this._name;
    }

    public void setName(String name){
        this._name = name;
    }

    public String getFamily(){
        return this._family;
    }

    public void setFamily(String family){
        this._family = family;
    }

    public String getEmail(){
        return this._email;
    }

    public void setEmail(String email){
        this._email = email;
    }

    public String getPass(){
        return this._pass;
    }

    public void setPass(String pass){
        this._pass = pass;
    }

    public String getPass1(){
        return this._pass1;
    }

    public void setPass1(String pass1){
        this._pass1 = pass1;
    }
}