package com.example.blog;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;


public class MainActivity extends AppCompatActivity {
    Button b1;
    EditText ed1,ed2;
    TextView tx1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final DatabaseHandler db = new DatabaseHandler(this) {
            @Override
            public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

            }
        };

        b1 = findViewById(R.id.login);
        ed1 = findViewById(R.id.email);
        ed2 = findViewById(R.id.password);
        tx1= findViewById(R.id.textView);


        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    List<Contact> contacts = db.getAllContacts();

                    for (Contact cn : contacts) {
                        String email =  cn.getEmail();
                        String pass = cn.getPass();
                        // Writing Contacts to log
                        if ((ed1.getText().toString().equals(email)) && (ed2.getText().toString().equals(pass)))
                        {
                            Toast.makeText(getApplicationContext(), "Welcome...", Toast.LENGTH_SHORT).show();
                            Intent ent = new Intent(getApplicationContext(), ScrollingActivity.class);
                            startActivity(ent);
                            break;
                        }
                        else
                            Toast.makeText(getApplicationContext(), "Wrong Credentials", Toast.LENGTH_SHORT).show();

                    }


            }
        });

        tx1.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), SigninActivity.class);
                startActivity(intent);
            }
        });
    }
}
