package com.example.blog;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;



public class SigninActivity extends AppCompatActivity {
    int a;
    int p;
    int c;
    int d;
    int e;
    int f;
    int g;

    public static boolean isNumber(final String str) {
        boolean found = false;
        for(char c : str.toCharArray()){
            if(Character.isDigit(c)){
                found = true;
            } else if(found){
                // If we already found a digit before and this char is not a digit, stop looping
                break;
            }
        }
        return found;
    }


    public static boolean isChar(String str)
    {
        return ((str != null) && (!str.equals("")) && (str.matches("^[a-zA-Z]*$")));
    }

    public boolean isSymbol(String s) {
        Pattern p = Pattern.compile("[^A-Za-z0-9]");
        Matcher m = p.matcher(s);
        // boolean b = m.matches();
        return m.find();
    }
    EditText FName, LName, Email, Pass ,Pass1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        final DatabaseHandler db = new DatabaseHandler(this) {
            @Override
            public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

            }
        };

        FName = findViewById(R.id.fname);
        LName = findViewById(R.id.lname);
        Email = findViewById(R.id.email);
        Pass = findViewById(R.id.password);
        Pass1 = findViewById(R.id.password1);




        final Button b = findViewById(R.id.signin);
        b.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                String t1 = FName.getText().toString();
                String t2 = LName.getText().toString();
                String t3 = Email.getText().toString();
                String t4 = Pass.getText().toString();
                String t5 = Pass1.getText().toString();
                if (t1.isEmpty() || t2.isEmpty() || t3.isEmpty() || t4.isEmpty() || t5.isEmpty()) {
                    Message.message(getApplicationContext(), "Some spaces are empty. Complet them!");
                  a=1; }else
                a=0;
                if (t4.length() < 8) {
                    Message.message(getApplicationContext(), "Passwords must contain 8-16 characters");
                  p=1; }else
                p=0;
                if (!isNumber(t4)) {
                    Message.message(getApplicationContext(), "Passwords must contain numbers");
                  c=1; }else
                c=0;
                if (isChar(t4)) {
                    Message.message(getApplicationContext(), "Passwords must contain letters");
                  d=1; }else
                d=0;
                if (!isSymbol(t4)) {
                    Message.message(getApplicationContext(), "Passwords must contain symbols");
                  e=1; }else
                e=0;
                if (!t4.equals(t5)){
                    Message.message(getApplicationContext(), "Passwords are not the same");
                      g=1; } else
                    g=0;

                    List<Contact> contacts = db.getAllContacts();

                for (Contact cn : contacts) {
                    String email = cn.getEmail();
                    String pass = cn.getPass();
                    // Writing Contacts to log
                    if ((t3.equals(email)) && (t4.equals(pass))){
                        Message.message(getApplicationContext(), "Email or Passwords already exist");
                        f=1;
                        break;
                    }else f=0;
                }

                    if(a != 1 && p != 1 && c != 1 && d != 1 && e != 1 && f != 1 && g != 1)
                        {
                            contacts = db.getAllContacts();
                            Log.d("Insert: ", "Inserting ..");
                            db.addContact(new Contact(t1, t2, t3, t4, t5));
                            Log.d("Reading: ", "Reading all contacts..");
                            for (Contact cn : contacts)
                            {
                                String log = "Id: " + cn.getID() + " ,Name: " + cn.getName() + " ,Family: " + cn.getFamily() + " ,Email: " + cn.getEmail() + " ,Password: " + cn.getPass() + " ,Repeat password: " + cn.getPass1();
                                     Log.d("Name: ", log);
                                     System.out.println(log);
                            }
                            Intent inte = new Intent(getApplicationContext(), MainActivity.class);
                            startActivity(inte);
                            Message.message(getApplicationContext(), "Acount created succesful");
                        }



            }
        });


    }

}
